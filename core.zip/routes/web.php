<?php

use App\Http\Controllers\CalendarPdfController;
use App\Http\Controllers\ProfileController;
use App\Livewire\Admin\Staff\StaffIndex;
use App\Livewire\Admin\Events\EventIndex;
use App\Livewire\CalendarView;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Public Homepage (No Login Required)
Route::get('/', function () {
    return view('welcome');
})->name('home');

// Public PDF Export
Route::get('/calendar/pdf', [CalendarPdfController::class, 'generate'])->name('calendar.pdf');

// Authenticated User Routes
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', function () {
        return redirect()->route('admin.staff.index');
    })->name('dashboard');

    Route::get('/calendar', CalendarView::class)->name('calendar.index');

    // Profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Admin Only Routes
Route::middleware(['auth', 'verified', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    // Staff Management (Livewire)
    Route::get('/', StaffIndex::class)->name('dashboard');
    Route::get('/staff', StaffIndex::class)->name('staff.index');

    // Calendar Events Management (Livewire)
    Route::get('/events', EventIndex::class)->name('events.index');
});

require __DIR__.'/auth.php';
