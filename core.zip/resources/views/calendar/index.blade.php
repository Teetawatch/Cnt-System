<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center">
                    <i class="fa-solid fa-calendar-days text-primary-600 dark:text-primary-400"></i>
                </div>
                <div>
                    <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                        {{ __('ปฏิทินการปฏิบัติงาน') }}
                    </h2>
                    <p class="text-sm text-gray-500 dark:text-gray-400">ดูตารางงานของผู้อำนวยการและรองผู้อำนวยการ</p>
                </div>
            </div>
            <div class="flex items-center gap-2">
                <button class="btn-secondary text-sm">
                    <i class="fa-solid fa-file-pdf me-2"></i>
                    พิมพ์ PDF
                </button>
            </div>
        </div>
    </x-slot>

    <!-- Filters -->
    <div class="glass-card p-4 mb-6 animate-fade-in">
        <div class="flex flex-wrap items-center gap-4">
            <div class="flex items-center gap-2">
                <label class="text-sm text-gray-600 dark:text-gray-400">วันที่:</label>
                <input type="date" value="{{ today()->format('Y-m-d') }}" class="form-input-custom text-sm">
            </div>
            <div class="flex items-center gap-2">
                <label class="text-sm text-gray-600 dark:text-gray-400">ผู้ปฏิบัติ:</label>
                <select class="form-input-custom text-sm w-56">
                    <option value="">ทั้งหมด</option>
                    @foreach(\App\Models\Staff::active()->ordered()->get() as $staff)
                        <option value="{{ $staff->id }}">{{ $staff->name }}</option>
                    @endforeach
                </select>
            </div>
            <button class="btn-primary text-sm">
                <i class="fa-solid fa-search me-2"></i>
                ค้นหา
            </button>
        </div>
    </div>

    <!-- Today's Date Header -->
    <div class="text-center mb-6">
        <h3 class="text-2xl font-bold text-gray-900 dark:text-white">
            {{ now()->locale('th')->translatedFormat('l') }}
        </h3>
        <p class="text-lg text-gray-600 dark:text-gray-400">
            {{ now()->locale('th')->translatedFormat('j F Y') }}
        </p>
    </div>

    <!-- Events by Staff -->
    @php
        $staffList = \App\Models\Staff::active()->ordered()->with(['calendarEvents' => function($query) {
            $query->forDate(today())->orderByTime();
        }])->get();
    @endphp

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        @foreach($staffList as $staff)
            <div class="glass-card overflow-hidden animate-slide-up">
                <!-- Staff Header -->
                <div class="bg-gradient-to-r from-primary-600 to-primary-700 p-4 text-white">
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                            @if($staff->photo)
                                <img src="{{ $staff->photo_url }}" alt="" class="w-12 h-12 rounded-full object-cover">
                            @else
                                <i class="fa-solid fa-user text-xl"></i>
                            @endif
                        </div>
                        <div>
                            <h4 class="font-semibold text-lg">{{ $staff->name }}</h4>
                            <p class="text-primary-100 text-sm">{{ $staff->position }}</p>
                        </div>
                    </div>
                </div>

                <!-- Events List -->
                <div class="p-4">
                    @forelse($staff->calendarEvents as $event)
                        <div class="flex gap-4 py-3 {{ !$loop->last ? 'border-b border-gray-100 dark:border-gray-700' : '' }}">
                            <div class="text-center min-w-[60px]">
                                <p class="text-sm font-semibold text-primary-600 dark:text-primary-400">
                                    {{ \Carbon\Carbon::parse($event->start_time)->format('H:i') }}
                                </p>
                                @if($event->end_time)
                                    <p class="text-xs text-gray-400">
                                        {{ \Carbon\Carbon::parse($event->end_time)->format('H:i') }}
                                    </p>
                                @endif
                            </div>
                            <div class="flex-1">
                                <p class="font-medium text-gray-900 dark:text-white">{{ $event->title }}</p>
                                <p class="text-sm text-gray-500">
                                    <i class="fa-solid fa-location-dot me-1"></i>
                                    {{ $event->location }}
                                </p>
                                @if($event->organization)
                                    <p class="text-sm text-gray-400">
                                        <i class="fa-solid fa-building me-1"></i>
                                        {{ $event->organization }}
                                    </p>
                                @endif
                            </div>
                            <span class="badge badge-{{ $event->status_color }} h-fit">
                                {{ $event->status_label }}
                            </span>
                        </div>
                    @empty
                        <div class="text-center py-8 text-gray-400">
                            <i class="fa-solid fa-calendar-xmark text-3xl mb-2"></i>
                            <p>ไม่มีกิจกรรมในวันนี้</p>
                        </div>
                    @endforelse
                </div>
            </div>
        @endforeach
    </div>

    @if($staffList->isEmpty())
        <div class="glass-card p-12 text-center text-gray-400">
            <i class="fa-solid fa-users-slash text-5xl mb-4"></i>
            <p class="text-xl mb-2">ยังไม่มีข้อมูลผู้ปฏิบัติงาน</p>
            <p class="text-sm">กรุณาติดต่อผู้ดูแลระบบเพื่อเพิ่มข้อมูล</p>
        </div>
    @endif
</x-app-layout>
