<div>
    <x-slot name="header">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-success-50 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                <i class="fa-solid fa-calendar-plus text-success-500 dark:text-green-400"></i>
            </div>
            <div>
                <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                    {{ __('จัดการกิจกรรม') }}
                </h2>
                <p class="text-sm text-gray-500 dark:text-gray-400">เพิ่ม แก้ไข ลบ รายการปฏิทินการปฏิบัติงาน</p>
            </div>
        </div>
    </x-slot>

    <!-- Action Button (inside Livewire scope) -->
    <div class="mb-6 flex justify-end">
        <button wire:click="openCreateModal" class="btn-primary">
            <i class="fa-solid fa-plus me-2"></i>
            เพิ่มกิจกรรม
        </button>
    </div>

    <!-- Flash Messages -->
    @if(session('success'))
        <div class="glass-card p-4 mb-6 border-l-4 border-success-500 bg-success-50 dark:bg-green-900/20 animate-fade-in">
            <div class="flex items-center">
                <i class="fa-solid fa-circle-check text-success-500 me-3"></i>
                <span class="text-green-700 dark:text-green-300">{{ session('success') }}</span>
            </div>
        </div>
    @endif

    <div class="glass-card animate-fade-in">
        <div class="p-6 border-b border-gray-200 dark:border-gray-700">
            <div class="flex flex-wrap items-center justify-between gap-4">
                <div class="flex items-center gap-4">
                    <span class="text-gray-600 dark:text-gray-400">
                        ทั้งหมด <span class="font-semibold text-gray-900 dark:text-white">{{ $events->total() }}</span> รายการ
                    </span>
                </div>
                <div class="flex flex-wrap items-center gap-2">
                    <input type="date" 
                           wire:model.live="filterDate" 
                           class="form-input-custom text-sm">
                    <select wire:model.live="filterStaff" class="form-input-custom text-sm w-48">
                        <option value="">ผู้ปฏิบัติทั้งหมด</option>
                        @foreach($staffList as $staff)
                            <option value="{{ $staff->id }}">{{ $staff->name }}</option>
                        @endforeach
                    </select>
                    <select wire:model.live="filterStatus" class="form-input-custom text-sm w-36">
                        <option value="">สถานะทั้งหมด</option>
                        <option value="pending">รอยืนยัน</option>
                        <option value="confirmed">ยืนยันแล้ว</option>
                        <option value="cancelled">ยกเลิก</option>
                    </select>
                    <div class="relative">
                        <i class="fa-solid fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input type="text" 
                               wire:model.live.debounce.300ms="search" 
                               placeholder="ค้นหา..." 
                               class="form-input-custom text-sm w-48 pl-10">
                    </div>
                    @if($search || $filterDate || $filterStaff || $filterStatus)
                        <button wire:click="clearFilters" class="btn-secondary text-sm">
                            <i class="fa-solid fa-xmark me-1"></i>
                            ล้าง
                        </button>
                    @endif
                </div>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50 dark:bg-gray-700/50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">วันที่/เวลา</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">รายการงาน</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">ผู้ปฏิบัติ</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">สถานที่</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">สถานะ</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">จัดการ</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                    @forelse($events as $event)
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors" wire:key="event-{{ $event->id }}">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div>
                                    <p class="font-medium text-gray-900 dark:text-white">{{ $event->event_date->format('d/m/Y') }}</p>
                                    <p class="text-sm text-gray-500">{{ $event->time_range }}</p>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="max-w-xs">
                                    <p class="font-medium text-gray-900 dark:text-white truncate">{{ $event->title }}</p>
                                    @if($event->organization)
                                        <p class="text-sm text-gray-500 truncate">{{ $event->organization }}</p>
                                    @endif
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center gap-2">
                                    <div class="w-8 h-8 bg-primary-100 dark:bg-primary-900/30 rounded-full flex items-center justify-center">
                                        <i class="fa-solid fa-user text-sm text-primary-600 dark:text-primary-400"></i>
                                    </div>
                                    <span class="text-sm text-gray-900 dark:text-white">{{ $event->staff->name }}</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                {{ $event->location }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="badge badge-{{ $event->status_color }}">{{ $event->status_label }}</span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm">
                                <button wire:click="openEditModal({{ $event->id }})" class="text-primary-600 hover:text-primary-700 me-3">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </button>
                                <button wire:click="confirmDelete({{ $event->id }})" class="text-danger-500 hover:text-danger-600">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center text-gray-400">
                                <i class="fa-solid fa-calendar-plus text-4xl mb-3"></i>
                                <p>ยังไม่มีกิจกรรม</p>
                                <button wire:click="openCreateModal" class="btn-primary mt-4">
                                    <i class="fa-solid fa-plus me-2"></i>
                                    เพิ่มกิจกรรมแรก
                                </button>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($events->hasPages())
            <div class="p-6 border-t border-gray-200 dark:border-gray-700">
                {{ $events->links() }}
            </div>
        @endif
    </div>

    <!-- Create/Edit Modal -->
    @if($showModal)
        <div class="fixed inset-0 z-50 overflow-y-auto">
            <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:p-0">
                <div class="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" wire:click="closeModal"></div>

                <div class="relative inline-block w-full max-w-2xl p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white dark:bg-gray-800 shadow-xl rounded-2xl animate-scale-in">
                    <div class="flex items-center justify-between mb-6">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="fa-solid fa-{{ $editMode ? 'pen-to-square' : 'calendar-plus' }} me-2 text-success-500"></i>
                            {{ $editMode ? 'แก้ไขกิจกรรม' : 'เพิ่มกิจกรรม' }}
                        </h3>
                        <button wire:click="closeModal" class="text-gray-400 hover:text-gray-500">
                            <i class="fa-solid fa-xmark text-xl"></i>
                        </button>
                    </div>

                    <form wire:submit="save">
                        <div class="space-y-4">
                            <!-- Staff Selection -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">ผู้ปฏิบัติงาน <span class="text-danger-500">*</span></label>
                                <select wire:model="staff_id" class="form-input-custom">
                                    <option value="">-- เลือกผู้ปฏิบัติงาน --</option>
                                    @foreach($staffList as $staff)
                                        <option value="{{ $staff->id }}">{{ $staff->name }} - {{ $staff->position }}</option>
                                    @endforeach
                                </select>
                                @error('staff_id') <p class="text-danger-500 text-sm mt-1">{{ $message }}</p> @enderror
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <!-- Date -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">วันที่ <span class="text-danger-500">*</span></label>
                                    <input type="date" wire:model="event_date" class="form-input-custom">
                                    @error('event_date') <p class="text-danger-500 text-sm mt-1">{{ $message }}</p> @enderror
                                </div>

                                <!-- Start Time -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">เวลาเริ่ม <span class="text-danger-500">*</span></label>
                                    <input type="time" wire:model="start_time" class="form-input-custom">
                                    @error('start_time') <p class="text-danger-500 text-sm mt-1">{{ $message }}</p> @enderror
                                </div>

                                <!-- End Time -->
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">เวลาสิ้นสุด</label>
                                    <input type="time" wire:model="end_time" class="form-input-custom">
                                    @error('end_time') <p class="text-danger-500 text-sm mt-1">{{ $message }}</p> @enderror
                                </div>
                            </div>

                            <!-- Title -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">รายการงาน <span class="text-danger-500">*</span></label>
                                <input type="text" wire:model="title" class="form-input-custom" placeholder="เช่น ประชุมคณะกรรมการ">
                                @error('title') <p class="text-danger-500 text-sm mt-1">{{ $message }}</p> @enderror
                            </div>

                            <!-- Location -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">สถานที่ <span class="text-danger-500">*</span></label>
                                <input type="text" wire:model="location" class="form-input-custom" placeholder="เช่น ห้องประชุมใหญ่ อาคาร 1">
                                @error('location') <p class="text-danger-500 text-sm mt-1">{{ $message }}</p> @enderror
                            </div>

                            <!-- Organization -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">หน่วยงานที่เชิญ/จัด</label>
                                <input type="text" wire:model="organization" class="form-input-custom" placeholder="เช่น คณะกรรมการสถานศึกษา">
                                @error('organization') <p class="text-danger-500 text-sm mt-1">{{ $message }}</p> @enderror
                            </div>

                            <!-- Description -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">รายละเอียดเพิ่มเติม</label>
                                <textarea wire:model="description" rows="3" class="form-input-custom" placeholder="รายละเอียดเพิ่มเติม (ถ้ามี)"></textarea>
                                @error('description') <p class="text-danger-500 text-sm mt-1">{{ $message }}</p> @enderror
                            </div>

                            <!-- Status -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">สถานะ <span class="text-danger-500">*</span></label>
                                <select wire:model="status" class="form-input-custom">
                                    <option value="pending">รอยืนยัน</option>
                                    <option value="confirmed">ยืนยันแล้ว</option>
                                    <option value="cancelled">ยกเลิก</option>
                                </select>
                                @error('status') <p class="text-danger-500 text-sm mt-1">{{ $message }}</p> @enderror
                            </div>
                        </div>

                        <div class="flex justify-end gap-3 mt-6">
                            <button type="button" wire:click="closeModal" class="btn-secondary">
                                ยกเลิก
                            </button>
                            <button type="submit" class="btn-primary" wire:loading.attr="disabled">
                                <span wire:loading.remove wire:target="save">
                                    <i class="fa-solid fa-check me-2"></i>
                                    {{ $editMode ? 'บันทึกการแก้ไข' : 'เพิ่มกิจกรรม' }}
                                </span>
                                <span wire:loading wire:target="save">
                                    <i class="fa-solid fa-spinner fa-spin me-2"></i>
                                    กำลังบันทึก...
                                </span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @endif

    <!-- Delete Confirmation Modal -->
    @if($showDeleteModal)
        <div class="fixed inset-0 z-50 overflow-y-auto">
            <div class="flex items-center justify-center min-h-screen px-4">
                <div class="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" wire:click="closeDeleteModal"></div>

                <div class="relative inline-block w-full max-w-md p-6 my-8 overflow-hidden text-center align-middle transition-all transform bg-white dark:bg-gray-800 shadow-xl rounded-2xl animate-scale-in">
                    <div class="w-16 h-16 bg-danger-50 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fa-solid fa-trash text-2xl text-danger-500"></i>
                    </div>

                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                        ยืนยันการลบ
                    </h3>
                    <p class="text-gray-500 dark:text-gray-400 mb-6">
                        คุณต้องการลบกิจกรรม <span class="font-semibold text-gray-900 dark:text-white">{{ $deleteTitle }}</span> หรือไม่?<br>
                        <span class="text-sm text-danger-500">การกระทำนี้ไม่สามารถยกเลิกได้</span>
                    </p>

                    <div class="flex justify-center gap-3">
                        <button type="button" wire:click="closeDeleteModal" class="btn-secondary">
                            ยกเลิก
                        </button>
                        <button type="button" wire:click="delete" class="btn-danger" wire:loading.attr="disabled">
                            <span wire:loading.remove wire:target="delete">
                                <i class="fa-solid fa-trash me-2"></i>
                                ลบกิจกรรม
                            </span>
                            <span wire:loading wire:target="delete">
                                <i class="fa-solid fa-spinner fa-spin me-2"></i>
                                กำลังลบ...
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
